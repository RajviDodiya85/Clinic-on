from django.contrib import admin

# Register your models here.

from .models import UserRegister

class UserRegisterAdmin(admin.ModelAdmin):
        list_display=['id','userfname','uid','usercontactno','userarea','usercity']


admin.site.register(UserRegister,UserRegisterAdmin)