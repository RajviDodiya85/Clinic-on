from django.shortcuts import render

# Create your views here.

from django.shortcuts import render,redirect
from django.http import request,HttpResponseRedirect,HttpResponse
from Doctorapp.models import DoctorRegister,Appointment,Checkup,guides
from .models import UserRegister
from .forms import UserRegisterForm
from Doctorapp.forms import  appointmentform
from django.db.models import Q



# from practice.decorator import status


# User signin 
def signin(request):
            #  return redirect('/signin/')
    return render(request,'userlogin.html')

#User logout
def logout(request):
    if 'user' in request.session.keys():
        del request.session['user']
        return redirect('doctor:home')
    return redirect('user:signin')



# User register
def signup(request):
    obj=UserRegisterForm(request.POST)
    if obj.is_valid():
        print(obj)
        b=UserRegister.objects.filter(uid=request.POST['uid'])
        if len(b)<=0:
            obj.save()
            print("done")
            return redirect('user:signin')
        else:
            return render(request,'usersignup_1.html',{'obj':obj,'m':'user alredy exists'})
    return render(request,'usersignup_1.html',{'obj':obj})

