from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect
from Doctorapp.models import DoctorRegister,Doctorcategory,Appointment,Contact
from patientapp.models import UserRegister
from django.shortcuts import render



#guest mode
def home(request):
    if request.session.has_key('user'):       
        user= request.session['user']
        return render (request,'index.html',{'sessiondata':user})
    elif request.session.has_key('doctor'):
        doctor= request.session['doctor']
        return render (request,'index.html',{'sessiondoctor':doctor})
    else:
        return render (request,'index.html')
    

def about(request):
    if request.session.has_key('user'):       
        user= request.session['user']
        return render (request,'about-us.html',{'sessiondata':user})
    elif request.session.has_key('doctor'):
        doctor= request.session['doctor']
        return render (request,'about-us.html',{'sessiondoctor':doctor})
    else:
        return render (request,'about-us.html')
    
def services(request):
    if request.session.has_key('user'):       
        user= request.session['user']
        return render (request,'services.html',{'sessiondata':user})
    elif request.session.has_key('doctor'):
        doctor= request.session['doctor']
        return render (request,'services.html',{'sessiondoctor':doctor})
    else:
        return render (request,'services.html')
    
    
def contact(request):
    if request.session.has_key('user'):       
        user= request.session['user']
        a=UserRegister.objects.get(uid=request.session['user'])
        if request.POST: 
            model=Contact()
            model.name=request.POST['name']
            model.email=request.POST['email']
            model.message=request.POST['message']
            model.save()
            return render (request,'contact.html',{'sessiondata':user,'n':a})
        return render (request,'contact.html',{'sessiondata':user,'n':a})
    elif request.session.has_key('doctor'):
        doctor= request.session['doctor']
        return render (request,'contact.html',{'sessiondoctor':doctor})
    else:
        if request.POST:  
            model=Contact()
            model.name=request.POST['name']
            model.email=request.POST['email']
            model.message=request.POST['message']
            model.save()
            return render (request,'contact.html')
        return render (request,'contact.html')
        

def d_index(request):
    if request.session.has_key('doctor'):
        doctor= request.session['doctor']
        total=Appointment.objects.filter(Doctor_name=request.session['doctorId'])
        approve=Appointment.objects.filter(status='approved') & Appointment.objects.filter(appointment_booked=False) & Appointment.objects.filter(Doctor_name=request.session['doctorId'])
        pending=Appointment.objects.filter(status='pending') & Appointment.objects.filter(Doctor_name=request.session['doctorId'])
        rejected=Appointment.objects.filter(status='rejected') & Appointment.objects.filter(Doctor_name=request.session['doctorId'])
        return render (request,'d_index.html',{'sessiondoctor':doctor,'total':len(total),'approve':len(approve),'pending':len(pending),'rejected':len(rejected)})
    else:
        return redirect('doctor:doc_signin')


# signin page
def doc_signin(request):
    return render(request,'doctorlogin.html')


        
# t signup
def doc_signup(request):
    ab=Doctorcategory.objects.all()
    obj=DoctorRegisterform(request.POST,request.FILES)
    print(obj)
    if obj.is_valid():
        b=DoctorRegister.objects.filter(Did=request.POST['Did'])
        print(len(b))
        if len(b)<=0:
            obj.save()
            print("done")
            return redirect('doctor:doc_signin')
        else:
            return render(request,'doctorsignup.html',{'ab':ab,'m':'user alredy exists'})
    return render(request,'doctorsignup.html',{'ab':ab})

# logout
def logout(request):
    # request.session.clear()
    del request.session['doctor']
    return redirect('doctor:home')

from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate
from django.contrib import messages

def custom_login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome {user.username}!")
            return redirect('/')
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})
