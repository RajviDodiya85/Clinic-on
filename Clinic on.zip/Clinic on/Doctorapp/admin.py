from django.contrib import admin

# Register your models here.
from django.contrib import admin
from Doctorapp.models import DoctorRegister,Doctorcategory,Appointment,Checkup,Contact,guides


admin.site.site_header = 'Dr.Medicare'                    # default: "Django Administration"
admin.site.index_title = 'Dr.Medicare'                 # default: "Site administration"
admin.site.site_title = 'Dr.Medicare' 


class DoctorRegisterAdmin(admin.ModelAdmin):
    list_display=['id','doctor_category','Doctorfname','Did','Doctorcontactno','Doctorarea','Doctorcity','Doctorphoto']
    list_filter=['id','doctor_category','Doctorcity']
admin.site.register(DoctorRegister,DoctorRegisterAdmin)
admin.site.register(Doctorcategory)
class DoctorAppointment(admin.ModelAdmin):
    list_display=['name','phone','email','schedule','Doctor_name','status']
admin.site.register(Appointment,DoctorAppointment)

class DoctorCheckup(admin.ModelAdmin):
    list_display=['name','email','Doctor_name','date_of_checkup']

admin.site.register(Checkup,DoctorCheckup)

class Contactadmin(admin.ModelAdmin):
    list_display=['name','email','date']
admin.site.register(Contact,Contactadmin)


class guideadmin(admin.ModelAdmin):
    list_display=['mname','side_effect','caution','unit','drug']
admin.site.register(guides,guideadmin)