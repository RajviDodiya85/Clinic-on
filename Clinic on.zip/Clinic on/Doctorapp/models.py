from django.db import models

# Create your models here.
from django.db import models

# doctor category
class Doctorcategory(models.Model):
    c_name=models.CharField(max_length=50,default='',verbose_name='Doctor_Category')
    def __str__(self):
        return self.c_name

# Doctor Details
class DoctorRegister(models.Model):
    doctor_category=models.ForeignKey(Doctorcategory,on_delete=models.CASCADE)
    Did=models.EmailField(max_length=50,verbose_name='Email')
    Doctorpwd=models.CharField(max_length=20,verbose_name='Password')
    Doctorfname=models.CharField(max_length=20,default='',verbose_name='First_Name')
    Doctormname=models.CharField(max_length=20,default='',verbose_name='Middle_Name')
    Doctorlname=models.CharField(max_length=20,default='',verbose_name='Last_Name')
    Doctoraddress=models.CharField(max_length=20,default='',verbose_name='Address')
    Doctorcity=models.CharField(max_length=20,default='',verbose_name='City')
    Doctorarea=models.CharField(max_length=20,default='',verbose_name='Area')
    Doctorpincode=models.IntegerField(default='',verbose_name='Pincode')
    Doctorcontactno=models.IntegerField(default='',verbose_name='Contact_No')
    Doctorphoto = models.FileField(upload_to='upload',verbose_name='Hospital certificate')
    
    def __str__(self):
        return str(self.Doctorfname)

class Appointment(models.Model):
    g = (
        ('pending', 'pending'),
        ('approved', 'approved'),
        ('rejected', 'rejected'),
    )
    name = models.CharField(max_length=500)
    phone = models.IntegerField()
    email = models.EmailField(max_length=100)
    schedule = models.DateTimeField()
    Doctor_name=models.ForeignKey(DoctorRegister, on_delete=models.CASCADE)
    status = models.CharField(max_length=12, choices=g, default = 'pending')
    appointment_booked=models.BooleanField(default=False)
    def __str__(self):
        return self.name

class Checkup(models.Model):    
    name = models.CharField(max_length=500)
    email = models.EmailField(max_length=100)
    Doctor_name=models.CharField(max_length=500)
    date_of_checkup=models.DateField(auto_created=True,auto_now=True)
    details=models.TextField()
    def __str__(self):
        return self.name

class Contact(models.Model):    
    name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255)
    message=models.TextField()
    date=models.DateField(auto_created=True,auto_now=True)
    
    def __str__(self):
        return self.name


# Medicine Details 

class guides(models.Model):
    mname=models.CharField(null='False',verbose_name='Medicine_Name',max_length=30)
    symptoms = models.CharField(max_length=1000, null='False')
    diseases = models.CharField(max_length=1000,null='False')
    category=models.CharField(null='False',verbose_name='Type',max_length=50)
    unit=models.CharField(max_length=10,null='False',verbose_name='Unit')
    unit_price=models.FloatField(null='False',verbose_name='Unit_price')
    package_unit=models.CharField(max_length=10,null='False',verbose_name='Package_Unit')
    package_price=models.FloatField(null='False',verbose_name='Package_price')
    drug=models.CharField(max_length=20,null='False',verbose_name='Drug_Name')
    per_unit=models.CharField(max_length=10,null='False',verbose_name='per_unit')
    indication=models.CharField(max_length=100,verbose_name='Indication')
    contraindication=models.CharField(max_length=100,verbose_name='Containdication')
    caution=models.CharField(max_length=500,null='True',verbose_name='Caution')
    side_effect=models.CharField(max_length=500,null='True',verbose_name='Side-Effect')
    
    def __str__(self):
        return self.mname
from django.db import models

class DoctorRegister(models.Model):
    Did = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    specialization = models.CharField(max_length=100)
    profile_pic = models.ImageField(upload_to='doctor_images/', blank=True, null=True)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.name
