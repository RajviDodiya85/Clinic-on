from django.urls import path
from Doctorapp.views import *

urlpatterns = [
    path('doctor_index/', d_index, name='d_doctor'),
    path('', home, name="home"),
    path('about/', about, name="about"),
    path('services/', services, name="services"),
    path('contact/', contact, name="contact"),
    path('doc_signin/', doc_signin, name="doc_signin"),
    path('signup/', doc_signup, name="doc_signup"),
    path('logout/', logout, name='logout'),
    path('login/', custom_login_view, name="login"),
]
