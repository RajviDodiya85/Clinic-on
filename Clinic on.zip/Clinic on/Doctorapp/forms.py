from django import forms
from Doctorapp.models import DoctorRegister,Appointment,Checkup


class DoctorRegisterform(forms.ModelForm):
    class Meta:
        model=DoctorRegister
        fields='__all__'


class appointmentform(forms.ModelForm):
    class Meta:
        model=Appointment
        model.schedule
        fields='__all__'

class Checkupform(forms.ModelForm):
    class Meta:
        model=Checkup
        fields='__all__'

from django import forms
from .models import DoctorRegister

class DoctorRegisterform(forms.ModelForm):
    class Meta:
        model = DoctorRegister
        fields = '__all__'
